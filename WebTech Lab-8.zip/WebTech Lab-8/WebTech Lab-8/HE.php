<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet"  href="style.css">
	<title>header</title>
</head>
<body>
<div class="header">
	<div class="left">
	<img src="Clogo.PNG" alt="logo">

	</div>


	<div class="right">

		<?php

		?>

		<a href="home.php">Home |</a>
		<a href="login.php">Login |</a>
		<a href="registration.php">Registration</a>


		
	</div>


</div>
</body>
</html>