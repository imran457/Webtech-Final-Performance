<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet"  href="style.css">
	<title>header</title>
</head>
<body>
<div class="header">
	<div class="left">
	<img src="Clogo.PNG" alt="logo">

	</div>


	<div class="right">

		<?php

		?>

		Logged in as<a href="Bob.php">Bob |</a>
		<a href="logout.php">Logout |</a>
		


		
	</div>


</div>
</body>
</html>